let INFO = [
    {
        "id": 1,
        "name": "Tiara Location",
        "description": "This is a test description that has a lot of characters so UI is possible to make UWU"
    },
    {
        "id": 2,
        "name": "Bucket Location",
        "description": "This is a test description that has a lot of characters so UI is possible to make UWU"
    },
    {
        "id": 3,
        "name": "Rocket Launcher Location",
        "description": "This is a test description that has a lot of characters so UI is possible to make UWU"
    },
    {
        "id": 4,
        "name": "Mona Lusa Location",
        "description": "This is a test description that has a lot of characters so UI is possible to make UWU"
    },
    {
        "id": 5,
        "name": "Gold Goose Statue Location",
        "description": "This is a test description that has a lot of characters so UI is possible to make UWU"
    },
    {
        "id": 6,
        "name": "Money Tree Location",
        "description": "This is a test description that has a lot of characters so UI is possible to make UWU"
    },
    {
        "id": 7,
        "name": "Toystation 5 Location ",
        "description": "This is a test description that has a lot of characters so UI is possible to make UWU"
    },
    {
        "id": 8,
        "name": "Skill Up 1",
        "description": "This is a test description that has a lot of characters so UI is possible to make UWU"
    },
    {
        "id": 9,
        "name": "Skill Up 2",
        "description": "This is a test description that has a lot of characters so UI is possible to make UWU"
    },
    {
        "id": 10,
        "name": "Skill Up 3",
        "description": "This is a test description that has a lot of characters so UI is possible to make UWU"
    }
]